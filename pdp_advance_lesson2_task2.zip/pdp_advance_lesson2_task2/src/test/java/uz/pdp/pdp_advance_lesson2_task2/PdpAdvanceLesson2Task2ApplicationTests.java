package uz.pdp.pdp_advance_lesson2_task2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdpAdvanceLesson2Task2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
