package uz.pdp.pdp_advance_lesson2_task2.task2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdpAdvanceLesson2Task2Application {

    public static void main(String[] args) {
        SpringApplication.run(PdpAdvanceLesson2Task2Application.class, args);
    }

}
