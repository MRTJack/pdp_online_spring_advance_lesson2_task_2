package uz.pdp.pdp_advance_lesson2_task2.task2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.BlogEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.repo.BlogRepository;

import java.util.List;

@Service
public class BlogService {

    @Autowired
    BlogRepository blogRepository;

    public List<BlogEntity> getAllBlogPosts() {
        return blogRepository.findAll();
    }

    public BlogEntity getBlogPostById(Long id) {
        return blogRepository.findById(id).orElse(null);
    }

    public BlogEntity saveBlogPost(BlogEntity blogPost) {
        return blogRepository.save(blogPost);
    }

    public BlogEntity updateBlogPost(Long id, BlogEntity updatedBlogPost) {
        BlogEntity existingBlogPost = blogRepository.findById(id).orElse(null);

        if (existingBlogPost != null) {
            existingBlogPost.setTitle(updatedBlogPost.getTitle());
            existingBlogPost.setContent(updatedBlogPost.getContent());
            return blogRepository.save(existingBlogPost);
        }

        return null;
    }

    public void deleteBlogPost(Long id) {
        blogRepository.deleteById(id);
    }
}

