package uz.pdp.pdp_advance_lesson2_task2.task2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.AboutUsEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.repo.AboutUsRepository;

import java.util.List;

@Service
public class AboutUsService {

    @Autowired
    AboutUsRepository aboutUsRepository;

    public List<AboutUsEntity> getAllAboutUsData() {
        return aboutUsRepository.findAll();
    }

    public AboutUsEntity getAboutUsById(Long id) {
        return aboutUsRepository.findById(id).orElse(null);
    }

    public AboutUsEntity saveAboutUsData(AboutUsEntity aboutUsEntity) {
        return aboutUsRepository.save(aboutUsEntity);
    }

    public AboutUsEntity updateAboutUs(Long id, AboutUsEntity updatedAboutUs) {
        AboutUsEntity existingAboutUs = aboutUsRepository.findById(id).orElse(null);

        if (existingAboutUs != null) {
            existingAboutUs.setHistory(updatedAboutUs.getHistory());
            existingAboutUs.setMission(updatedAboutUs.getMission());
            existingAboutUs.setValues(updatedAboutUs.getValues());
            return aboutUsRepository.save(existingAboutUs);
        }

        return null;
    }

    public void deleteAboutUs(Long id) {
        aboutUsRepository.deleteById(id);
    }
}

