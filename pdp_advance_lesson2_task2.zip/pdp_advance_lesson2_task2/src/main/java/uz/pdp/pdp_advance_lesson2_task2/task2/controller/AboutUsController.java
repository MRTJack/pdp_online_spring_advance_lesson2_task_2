package uz.pdp.pdp_advance_lesson2_task2.task2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.AboutUsEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.service.AboutUsService;

import java.util.List;

@RestController
@RequestMapping("/api/about-us")
public class AboutUsController {

    @Autowired
    AboutUsService aboutUsService;

    @GetMapping
    public ResponseEntity<List<AboutUsEntity>> getAllAboutUsData() {
        List<AboutUsEntity> aboutUsData = aboutUsService.getAllAboutUsData();
        return new ResponseEntity<>(aboutUsData, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AboutUsEntity> getAboutUsById(@PathVariable Long id) {
        AboutUsEntity aboutUs = aboutUsService.getAboutUsById(id);
        if (aboutUs != null) {
            return new ResponseEntity<>(aboutUs, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<AboutUsEntity> saveAboutUsData(@RequestBody AboutUsEntity aboutUsEntity) {
        AboutUsEntity savedAboutUs = aboutUsService.saveAboutUsData(aboutUsEntity);
        return new ResponseEntity<>(savedAboutUs, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AboutUsEntity> updateAboutUs(@PathVariable Long id,
                                                       @RequestBody AboutUsEntity updatedAboutUs) {
        AboutUsEntity updatedEntity = aboutUsService.updateAboutUs(id, updatedAboutUs);
        if (updatedEntity != null) {
            return new ResponseEntity<>(updatedEntity, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAboutUs(@PathVariable Long id) {
        aboutUsService.deleteAboutUs(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

