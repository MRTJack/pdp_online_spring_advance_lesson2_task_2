package uz.pdp.pdp_advance_lesson2_task2.task2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.ReviewsEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.service.ReviewsService;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
public class ReviewsController {

    @Autowired
    ReviewsService reviewsService;

    @GetMapping
    public ResponseEntity<List<ReviewsEntity>> getAllReviews() {
        List<ReviewsEntity> reviews = reviewsService.getAllReviews();
        return new ResponseEntity<>(reviews, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReviewsEntity> getReviewById(@PathVariable Long id) {
        ReviewsEntity review = reviewsService.getReviewById(id);
        if (review != null) {
            return new ResponseEntity<>(review, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<ReviewsEntity> saveReview(@RequestBody ReviewsEntity review) {
        ReviewsEntity savedReview = reviewsService.saveReview(review);
        return new ResponseEntity<>(savedReview, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ReviewsEntity> updateReview(@PathVariable Long id,
                                                      @RequestBody ReviewsEntity updatedReview) {
        ReviewsEntity updatedEntity = reviewsService.updateReview(id, updatedReview);
        if (updatedEntity != null) {
            return new ResponseEntity<>(updatedEntity, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReview(@PathVariable Long id) {
        reviewsService.deleteReview(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

