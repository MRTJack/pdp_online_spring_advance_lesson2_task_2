package uz.pdp.pdp_advance_lesson2_task2.task2.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.PaymentDeliveryEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.service.PaymentDeliveryService;

import java.util.List;

@RestController
@RequestMapping("/api/payment_delivery")
public class PaymentDeliveryController {
    @Autowired
    PaymentDeliveryService paymentDeliveryService;

    @GetMapping
    public List<PaymentDeliveryEntity> getAllPaymentDeliveryData() {
        return paymentDeliveryService.getAllPaymentDeliveryData();
    }

    @GetMapping("/{id}")
    public PaymentDeliveryEntity getPaymentDeliveryById(@PathVariable Long id) {
        return paymentDeliveryService.getPaymentDeliveryById(id);
    }

    @PostMapping
    public PaymentDeliveryEntity savePaymentDeliveryData(@RequestBody PaymentDeliveryEntity paymentDeliveryEntity) {
        return paymentDeliveryService.savePaymentDeliveryData(paymentDeliveryEntity);
    }

    @PutMapping("/{id}")
    public PaymentDeliveryEntity updatePaymentDelivery(@PathVariable Long id, @RequestBody PaymentDeliveryEntity updatedPaymentDelivery) {
        return paymentDeliveryService.updatePaymentDelivery(id, updatedPaymentDelivery);
    }

    @DeleteMapping("/{id}")
    public void deletePaymentDelivery(@PathVariable Long id) {
        paymentDeliveryService.deletePaymentDelivery(id);
    }
}

