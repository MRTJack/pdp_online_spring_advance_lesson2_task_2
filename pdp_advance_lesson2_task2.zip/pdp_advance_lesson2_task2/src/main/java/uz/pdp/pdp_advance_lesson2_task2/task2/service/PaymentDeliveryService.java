package uz.pdp.pdp_advance_lesson2_task2.task2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.PaymentDeliveryEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.repo.PaymentDeliveryRepository;

import java.util.List;

@Service
public class PaymentDeliveryService {

    private final PaymentDeliveryRepository paymentDeliveryRepository;

    @Autowired
    public PaymentDeliveryService(PaymentDeliveryRepository paymentDeliveryRepository) {
        this.paymentDeliveryRepository = paymentDeliveryRepository;
    }

    public List<PaymentDeliveryEntity> getAllPaymentDeliveryData() {
        return paymentDeliveryRepository.findAll();
    }

    public PaymentDeliveryEntity getPaymentDeliveryById(Long id) {
        return paymentDeliveryRepository.findById(id).orElse(null);
    }

    public PaymentDeliveryEntity savePaymentDeliveryData(PaymentDeliveryEntity paymentDeliveryEntity) {
        return paymentDeliveryRepository.save(paymentDeliveryEntity);
    }

    public PaymentDeliveryEntity updatePaymentDelivery(Long id, PaymentDeliveryEntity updatedPaymentDelivery) {
        PaymentDeliveryEntity existingPaymentDelivery = paymentDeliveryRepository.findById(id).orElse(null);

        if (existingPaymentDelivery != null) {
            existingPaymentDelivery.setPaymentMethod(updatedPaymentDelivery.getPaymentMethod());
            existingPaymentDelivery.setDeliveryMethod(updatedPaymentDelivery.getDeliveryMethod());
            return paymentDeliveryRepository.save(existingPaymentDelivery);
        }

        return null;
    }

    public void deletePaymentDelivery(Long id) {
        paymentDeliveryRepository.deleteById(id);
    }
}

