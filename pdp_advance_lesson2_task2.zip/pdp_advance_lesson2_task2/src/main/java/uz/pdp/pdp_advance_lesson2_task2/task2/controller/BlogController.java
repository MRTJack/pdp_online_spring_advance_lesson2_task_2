package uz.pdp.pdp_advance_lesson2_task2.task2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.pdp.pdp_advance_lesson2_task2.task2.entity.BlogEntity;
import uz.pdp.pdp_advance_lesson2_task2.task2.service.BlogService;

import java.util.List;

@RestController
@RequestMapping("/api/blog")
public class BlogController {
    @Autowired
    BlogService blogService;

    @GetMapping
    public ResponseEntity<List<BlogEntity>> getAllBlogPosts() {
        List<BlogEntity> blogPosts = blogService.getAllBlogPosts();
        return new ResponseEntity<>(blogPosts, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BlogEntity> getBlogPostById(@PathVariable Long id) {
        BlogEntity blogPost = blogService.getBlogPostById(id);
        if (blogPost != null) {
            return new ResponseEntity<>(blogPost, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<BlogEntity> saveBlogPost(@RequestBody BlogEntity blogPost) {
        BlogEntity savedBlogPost = blogService.saveBlogPost(blogPost);
        return new ResponseEntity<>(savedBlogPost, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<BlogEntity> updateBlogPost(@PathVariable Long id,
                                                     @RequestBody BlogEntity updatedBlogPost) {
        BlogEntity updatedEntity = blogService.updateBlogPost(id, updatedBlogPost);
        if (updatedEntity != null) {
            return new ResponseEntity<>(updatedEntity, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBlogPost(@PathVariable Long id) {
        blogService.deleteBlogPost(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

